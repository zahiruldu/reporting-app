<?php

require_once('db.php');



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Home | Verizon</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">

  </head>
  <body>
    
    <div class="container-fluid">
    <div class="container"><img src="img/verizon-logo.png" width="100" height="" alt="Verizon"></div>
        <div class="container">
          <div style="text-align:center; margin-bottom: 50px;"><h1>Verizone Global Wholesale</h1>
          <h3>Public laaS Requests: Ad-Hoc Search</h3></div>
          <div class="row">
            <div class="col-sm-3">
              <div class="list-group">
              <a href="weekly_report.php"><button type="button" class="list-group-item" active>Weekly Request</button></a>
              <a href="monthly_report.php"><button type="button" class="list-group-item">Monthly Requests</button></a>
              <a href="monthly_trend_report.php"><button type="button" class="list-group-item">Monthly Trend Report Requests</button></a>
              <a href="index.php"><button type="button" class="list-group-item">Ad-Hoc Report</button></a>
              
            </div>
            </div>

            <div class="col-sm-9">
              <form class="form-inline" role="form" action="" method="post">
                <div class="form-group">
                  <label ></label>
                  <input type="text" class="form-control" name="search_text" size="40" placeholder="What are you looking for?">
                </div>
                <div class="form-group">
                  
                  <select class="form-control" name="company">
                  <?php 
                  $db=dbconnect();
                  $sql2="SELECT distinct company_name FROM customer";
                  $result2=mysqli_query($db,$sql2);
                    if (mysqli_num_rows($result2)>0) {
                        while($row2=mysqli_fetch_array($result2)){
                          $company=$row2["company_name"];
                          echo "<option>$company</option>";
                        }
                    }else{
                      echo mysqli_error($db);
                    }
                  ?>
                    
                  </select>
                </div>
                
                <input type="submit" class="btn btn-default" name="search" value="search" />
              </form>
              

            </div>
          </div>

          <?php 
          $db=dbconnect();
          if (isset($_POST['search']) && !empty($_POST['company'])) {
              $search_text=$_POST['search_text'];
              $company=$_POST['company'];


              echo "$search_text <br> $company";
                  $sql= "SELECT * FROM customer WHERE company_name='$company' AND last_name LIKE '%$search_text%'";
                 // $sql="SELECT * FROM customer WHERE company_name='$company' OR MATCH(last_name, first_name) AGAINST('$search_text')";
                  $result= mysqli_query($db, $sql);
                  if (mysqli_num_rows($result)>0) {

                      echo "<table id='hell' class='table table-striped table-bordered' cellspacing='0' width='100%'>";
                      echo "<thead id='heading_style'><tr><th>Last Name</th><th>First Name</th><th>Company</th><th>Email</th><th>Date</th><th>Time</th> </tr></thead>";
                      echo "<tbody>";
                      while($row=mysqli_fetch_array($result)){
                        $id=$row["id"];
                        $customer_id=$row["customer_id"];
                        $last_name=$row["last_name"];
                        $first_name=$row["first_name"];
                        $company=$row["company_name"];
                        $email=$row["email"];
                        $date=$row["get_date"];
                        $time=$row["get_time"];

                        echo "<tr>";
                        echo "<td>$last_name</td>";
                        echo "<td>$first_name</td>";
                        echo "<td>$company</td>";
                        echo "<td>$email</td>";
                        echo "<td>".date('M d Y', strtotime($date))."</td>";
                        echo "<td>".date('h:i A', strtotime($time))."</td>";
                        echo "</tr>";
                      }

                      echo "</tbody></table>";

                  }

          }else{

                  $sql= "SELECT * FROM customer";
                  $result= mysqli_query($db, $sql);
                  if (mysqli_num_rows($result)>0) {

                      echo "<table id='hell' class='table table-striped table-bordered' cellspacing='0' width='100%'>";
                      echo "<thead id='heading_style'><tr><th>Last Name</th><th>First Name</th><th>Company</th><th>Email</th><th>Date</th><th>Time</th> </tr></thead>";
                      echo "<tbody>";
                      while($row=mysqli_fetch_array($result)){
                        $id=$row["id"];
                        $customer_id=$row["customer_id"];
                        $last_name=$row["last_name"];
                        $first_name=$row["first_name"];
                        $company=$row["company_name"];
                        $email=$row["email"];
                        $date=$row["get_date"];
                        $time=$row["get_time"];

                        echo "<tr>";
                        echo "<td>$last_name</td>";
                        echo "<td>$first_name</td>";
                        echo "<td>$company</td>";
                        echo "<td>$email</td>";
                        echo "<td>".date('M d Y', strtotime($date))."</td>";
                        echo "<td>".date('h:i A', strtotime($time))."</td>";
                        echo "</tr>";
                      }

                      echo "</tbody></table>";

                  }

        }



          ?>

        </div>
        
      
    </div>








    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
    $('#example').dataTable();
    $('#hello').dataTable();

     } );
    </script>
    <script  src="js/dataTables.bootstrap.js"></script>
    <script  src="js/jquery.dataTables.js"></script>
  </body>
</html>