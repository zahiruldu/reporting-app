<?php

require_once('db.php');



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Monthly Report | Verizone</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.theme.css">



  </head>
  <body>
    
    <div class="container-fluid">
    <div class="container"><img src="img/verizon-logo.png" width="100" height="" alt="Verizon"></div>
        <div class="container">
         <div style="text-align:center; margin-bottom: 50px;"><h1>Verizone Global Wholesale</h1>
          <h3>Monthly Public laaS Requests</h3></div>
          <div class="row">
            <div class="col-sm-3">
              <div class="list-group">
              <a href="weekly_report.php"><button type="button" class="list-group-item" active>Weekly Request</button></a>
              <a href="monthly_report.php"><button type="button" class="list-group-item">Monthly Requests</button></a>
              <a href="monthly_trend_report.php"><button type="button" class="list-group-item">Monthly Trend Report Requests</button></a>
              <a href="index.php"><button type="button" class="list-group-item">Ad-Hoc Report</button></a>
              
            </div>
            </div>

            <div class="col-sm-9">
              <form class="form-inline" role="form" action="" method="post">
                <div class="form-group">
                  <label >Start</label>
                  <div class='input-group date'>
                    <input type="text" id="from" name="from" class="form-control">
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                </div>
                &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                <div class="form-group">
                <label>End</label>
                <div class='input-group date'>
                    <input type="text" id="to" name="to" class="form-control">
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                  
                </div>
                
                <input type="submit" class="btn btn-default" name="search_range" value="Search"/ >
              </form>             
              

            </div>
          </div>

          <?php 
          $db=dbconnect();
          if (isset($_POST['search_range']) && !empty($_POST['from']) && !empty($_POST['to'])) {
              $start=$_POST['from'];
              $end= $_POST['to'];
              $starting = date("Y-m-d", strtotime($start));
              $ending = date("Y-m-d", strtotime($end));
              

                  $sql= "SELECT * FROM customer WHERE get_date>='$starting' AND get_date<='$ending'";
                  $result= mysqli_query($db, $sql);
                  if (mysqli_num_rows($result)>0) {

                      echo "<table id='hello' class='table table-striped table-bordered' cellspacing='0' width='100%'>";
                      echo "<thead id='heading_style'><tr><th>Last Name</th><th>First Name</th><th>Company</th><th>Email</th><th>Date</th><th>Time</th> </tr></thead>";
                      echo "<tbody>";
                      while($row=mysqli_fetch_array($result)){
                        $id=$row["id"];
                        $customer_id=$row["customer_id"];
                        $last_name=$row["last_name"];
                        $first_name=$row["first_name"];
                        $company=$row["company_name"];
                        $email=$row["email"];
                        $date=$row["get_date"];
                        $time=$row["get_time"];

                        echo "<tr>";
                        echo "<td>$last_name</td>";
                        echo "<td>$first_name</td>";
                        echo "<td>$company</td>";
                        echo "<td>$email</td>";
                        echo "<td>".date('M d Y', strtotime($date))."</td>";
                        echo "<td>".date('h:i A', strtotime($time))."</td>";
                        echo "</tr>";
                      }

                      echo "</tbody></table>";

                  }

          }else{

                    $sql= "SELECT * FROM customer";
                    $result= mysqli_query($db, $sql);
                    if (mysqli_num_rows($result)>0) {

                        echo "<table id='hello' class='table table-striped table-bordered' cellspacing='0' width='100%'>";
                        echo "<thead id='heading_style'><tr><th>Last Name</th><th>First Name</th><th>Company</th><th>Email</th><th>Date</th><th>Time</th> </tr></thead>";
                        echo "<tbody>";
                        while($row=mysqli_fetch_array($result)){
                          $id=$row["id"];
                          $customer_id=$row["customer_id"];
                          $last_name=$row["last_name"];
                          $first_name=$row["first_name"];
                          $company=$row["company_name"];
                          $email=$row["email"];
                          $date=$row["get_date"];
                          $time=$row["get_time"];

                          echo "<tr>";
                          echo "<td>$last_name</td>";
                          echo "<td>$first_name</td>";
                          echo "<td>$company</td>";
                          echo "<td>$email</td>";
                          echo "<td>".date('M d Y', strtotime($date))."</td>";
                          echo "<td>".date('h:i A', strtotime($time))."</td>";
                          echo "</tr>";
                        }

                        echo "</tbody></table>";

                    }

        }



          ?>

        </div>

        
      
    </div>








    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
    $('#example').dataTable();
    $('#hello').dataTable();
    

     } );
    </script>
    <script  src="js/dataTables.bootstrap.js"></script>
    <script  src="js/jquery.dataTables.js"></script>
    <script  src="js/dataTables.tableTools.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script>
  $(function() {
    $( "#from" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 2,
      onClose: function( selectedDate ) {
        $( "#to" ).datepicker( "option", "minDate", selectedDate );
      }
    });
    $( "#to" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 2,
      onClose: function( selectedDate ) {
        $( "#from" ).datepicker( "option", "maxDate", selectedDate );
      }
    });
  });
  </script>

  </body>
</html>