<?php

/////////////////////////
 // Database configuration //
 ////////////////////////
$host ="localhost";
$user ="root";
$pass ="root";
$dbname = "verizone";


/////////////////////////
 // Database connection function //
 ////////////////////////

function dbconnect(){
	global $host, $user, $pass, $dbname;

	$conn = mysqli_connect($host,$user,$pass,$dbname);

	return $conn;
}
